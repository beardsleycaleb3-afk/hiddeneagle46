/**
 * HIDDENEAGLE46 • CASCADE ALGEBRA ENGINE
 * Core directional multiplication, parity validation, fold logic
 * 
 * Usage:
 *   const result = cascade(4, 4, 4);  // → 100
 *   const stable = fold(result);       // → parity-balanced equivalent
 */

class CascadeAlgebra {
  /**
   * Cascade multiplication: a ⊗ b ⊗ c ⊗ ...
   * First operand passes through; each subsequent adds iteratively.
   */
  static cascade(...operands) {
    if (operands.length === 0) return 0;
    if (operands.length === 1) return operands[0];

    let accumulator = operands[0]; // First is identity

    for (let i = 1; i < operands.length; i++) {
      const operand = operands[i];

      // Asymmetric zero rules
      if (operand === 0) {
        // x ⊗ 0 = x (right-zero preservation)
        continue;
      }
      if (accumulator === 0 && i > 1) {
        // 0 ⊗ x = 0 (left-zero annihilation)
        return 0;
      }

      // Cascade: accumulator + (accumulator × operand)
      accumulator = accumulator + (accumulator * operand);
    }

    return accumulator;
  }

  /**
   * Count 1-bits in binary representation (Hamming weight)
   */
  static parityBits(n) {
    let count = 0;
    let val = Math.abs(n) >>> 0; // Unsigned 32-bit
    while (val) {
      count += val & 1;
      val >>>= 1;
    }
    return count;
  }

  /**
   * Check if number has even parity (even number of 1-bits)
   */
  static isEvenParity(n) {
    return CascadeAlgebra.parityBits(n) % 2 === 0;
  }

  /**
   * Fold to parity equilibrium
   * If odd parity, apply transformations until even
   */
  static fold(n) {
    if (n < 0) return CascadeAlgebra.fold(-n); // Handle negatives by sign

    if (CascadeAlgebra.isEvenParity(n)) {
      return n; // Already stable
    }

    // Odd parity: apply folding transformations
    const complement = (~n) & 0xFF;           // 8-bit complement
    const lowerHalf = n & 0x0F;               // Lower 4 bits
    const fold1 = n ^ complement;             // XOR with complement
    const fold2 = n ^ lowerHalf;              // XOR with lower half
    const fold3 = (n + complement) & 0xFF;    // Sum & mask

    // Find first even-parity result
    const candidates = [fold1, fold2, fold3];
    for (const candidate of candidates) {
      if (CascadeAlgebra.isEvenParity(candidate)) {
        return candidate;
      }
    }

    // Fallback: bitwise rotation
    const rotated = ((n << 1) | (n >> 7)) & 0xFF;
    return CascadeAlgebra.isEvenParity(rotated) ? rotated : rotated ^ 1;
  }

  /**
   * Mirror algebra: encode operands as quaterbase4i (p, d, b, q)
   * p=00, d=01, b=10, q=11
   */
  static toQuaterbase4i(n) {
    const binary = (n & 0xFF).toString(2).padStart(8, '0');
    const pairs = [
      binary.substring(0, 2),
      binary.substring(2, 4),
      binary.substring(4, 6),
      binary.substring(6, 8),
    ];

    const map = { '00': 'p', '01': 'd', '10': 'b', '11': 'q' };
    return pairs.map(pair => map[pair]).join('');
  }

  /**
   * Reverse: quaterbase4i string → decimal
   */
  static fromQuaterbase4i(strand) {
    const map = { p: '00', d: '01', b: '10', q: '11' };
    const binary = strand.split('').map(c => map[c] || '00').join('');
    return parseInt(binary, 2);
  }

  /**
   * Validate cascade result: compute, fold, return stable state
   */
  static validate(...operands) {
    const raw = CascadeAlgebra.cascade(...operands);
    const stable = CascadeAlgebra.fold(raw);
    return {
      raw,
      stable,
      parity: CascadeAlgebra.isEvenParity(stable) ? 'even' : 'odd',
      binary: (stable & 0xFF).toString(2).padStart(8, '0'),
      quaterbase4i: CascadeAlgebra.toQuaterbase4i(stable),
      valid: CascadeAlgebra.isEvenParity(stable),
    };
  }

  /**
   * Game state collision: playerState ⊗ tileState
   * Returns stable new state
   */
  static collide(playerState, tileState) {
    const result = CascadeAlgebra.cascade(playerState, tileState);
    const stable = CascadeAlgebra.fold(result);
    return stable;
  }

  /**
   * Obliteration check: did left-zero annihilate?
   * Used when tile approaches player from forbidden direction
   */
  static checkObliteration(tileValue, playerState) {
    // 0 ⊗ playerState = 0 (annihilation)
    if (tileValue === 0 && playerState !== 0) {
      return true; // Obliteration triggered
    }
    return false;
  }

  /**
   * String representation for logging
   */
  static describe(n) {
    const quater = CascadeAlgebra.toQuaterbase4i(n);
    const parity = CascadeAlgebra.isEvenParity(n) ? '✓ EVEN' : '✗ ODD';
    return `[${n}] ${parity} | QBase4i: ${quater} | Binary: ${(n & 0xFF).toString(2).padStart(8, '0')}`;
  }
}

// Export for Node/CommonJS
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CascadeAlgebra;
}

/*_______________________*// add new code snippet here._________________,;

// TEST SUITE (run in browser console or Node)
function runCascadeTests() {
  console.log('=== HIDDENEAGLE46 CASCADE ALGEBRA TEST SUITE ===\n');

  // Test 1: Basic cascade
  console.log('TEST 1: 2 ⊗ 2 ⊗ 2');
  const test1 = CascadeAlgebra.validate(2, 2, 2);
  console.log(`Expected: 18, Got: ${test1.raw}, Stable: ${test1.stable}`);
  console.log(CascadeAlgebra.describe(test1.stable));
  console.log('');

  // Test 2: 4 ⊗ 4 ⊗ 4
  console.log('TEST 2: 4 ⊗ 4 ⊗ 4');
  const test2 = CascadeAlgebra.validate(4, 4, 4);
  console.log(`Expected: 100, Got: ${test2.raw}, Stable: ${test2.stable}`);
  console.log(CascadeAlgebra.describe(test2.stable));
  console.log('');

  // Test 3: Asymmetric zero (right)
  console.log('TEST 3: 5 ⊗ 0 (right-zero preservation)');
  const test3 = CascadeAlgebra.validate(5, 0);
  console.log(`Expected: 5, Got: ${test3.raw}`);
  console.log('');

  // Test 4: Parity validation
  console.log('TEST 4: Parity checks');
  const nums = [18, 100, 64, 42];
  nums.forEach(n => {
    const parity = CascadeAlgebra.isEvenParity(n) ? 'PASS ✓' : 'FAIL ✗';
    console.log(`${n}: ${parity} | Bits: ${CascadeAlgebra.parityBits(n)}`);
  });
  console.log('');

  // Test 5: Quaterbase4i encoding
  console.log('TEST 5: Quaterbase4i encoding');
  [18, 100, 64].forEach(n => {
    const qb4i = CascadeAlgebra.toQuaterbase4i(n);
    console.log(`${n} → ${qb4i}`);
  });
  console.log('');

  console.log('=== TESTS COMPLETE ===');
}

// Uncomment to run: runCascadeTests();
*/
